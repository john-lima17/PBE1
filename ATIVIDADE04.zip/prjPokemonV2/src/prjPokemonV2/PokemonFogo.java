package prjPokemonV2;

public class PokemonFogo extends Pokemon {

	// Métodos da SubClasse
	public void bolaFogo() {
		System.out.println(this.getNome() + " bola de fogo!");
	}

	public void explosaoFogo() {
		System.out.println(this.getNome() + " explosão");
	}

	public void lancaChamas() {
		System.out.println(this.getNome() + "chamas");

	}

	@Override
	public void Atacar() {
		System.out.println("Atacou com fogo");
	}
}