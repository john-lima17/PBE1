package ListaExercicios;

public class Aplicacao01 {

    public static void main(String[] args) {
        // Criando objetos da classe Exercicio01
        Aplicacao01 hb20 = new Exercicio01();
        hb20.marca = "Hyundai";
        hb20.modelo = "Hb20";
        hb20.placa = "DNS_1452";
        hb20.ano = 2015;
        
        Aplicacao01 hrv = new Exercicio01("Hyundai", "HR-V", "JAO_2307", 2020);
        
        // Exibindo informações dos objetos
        hb20.exibirInfo();
        hrv.exibirInfo();
    }
}