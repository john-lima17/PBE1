package ListaExercicios;

public class Aplicacao02 {

    public static void main(String[] args) {
        // Criando objetos da classe Exercicio02 e inicializando seus atributos
        Exercicio02 jonhys = new Exercicio02();
        jonhys.titulo = "As Aventuras de Jonhys";
        jonhys.autor = "Ana Cristina";
        jonhys.numPaginas = 256;
        jonhys.preco = 69.90;
        
        Exercicio02 jonhys2 = new Exercicio02();
        jonhys2.titulo = "As Aventuras de Jonhys na Amazonia";
        jonhys2.autor = "Ana Cristina";
        jonhys2.numPaginas = 134;
        jonhys2.preco = 80.99;
        
        Exercicio02 jonhys3 = new Exercicio02();
        jonhys3.titulo = "As Descobertas de Jonhys no Oceano";
        jonhys3.autor = "Ana Cristina";
        jonhys3.numPaginas = 342;
        jonhys3.preco = 120.99;
        
        // Exibindo informações dos objetos
        jonhys.exibirInfo();
        jonhys2.exibirInfo();
        jonhys3.exibirInfo();
    }
}
