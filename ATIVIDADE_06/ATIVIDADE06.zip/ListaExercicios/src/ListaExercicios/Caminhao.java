package ListaExercicios;

public class Caminhao {

	// Atributos
		public String marca;
		public String modelo;
		public int velocidade;

	    // Construtor padrão
	    public Caminhao() {
	    	
	    }

	    // Construtor parametrizado
	    public Caminhao(String marca, String modelo, int velocidade) {
	        this.marca = marca;
	        this.modelo = modelo;
	        this.velocidade = velocidade;
	    }

	    // Sobrescrevendo o método acelerar
	   
	    public void acelerar() {
	        this.acelerar();
	        System.out.println("O caminhão está acelerando");
	    }

	    // Sobrescrevendo o método frear
	    
	    public void frear() {
	        this.frear();
	        System.out.println("O caminhão está freando");
	    }
	}
