package ListaExercicios;

public class Exercicio01 {
	
	// Atributos
	public String marca;
	public String modelo;
	public String placa;
	public int ano;

	// Construtores
	public Exercicio01() {
	}

	public Exercicio01(String marca, String modelo, String placa, int ano) {
	    this.marca = marca;
	    this.modelo = modelo;
	    this.placa = placa;
	    this.ano = ano;
	}
	
	// Métodos
	public void exibirInfo() {
	    System.out.println("Marca: " + this.marca);
	    System.out.println("Modelo: " + this.modelo);
	    System.out.println("Placa: " + this.placa);
	    System.out.println("Ano: " + this.ano);
	}
}