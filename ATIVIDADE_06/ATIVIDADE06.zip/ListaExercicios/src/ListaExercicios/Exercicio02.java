package ListaExercicios;

public class Exercicio02 {

    // Atributos
    public String titulo;
    public String autor;
    public int numPaginas;
    public double preco;

    // Construtores
    public Exercicio02() {
    }

    public Exercicio02(String titulo, String autor, int numPaginas, double preco) {
        this.titulo = titulo;
        this.autor = autor;
        this.numPaginas = numPaginas;
        this.preco = preco;
    }

    // Getters e Setters
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getNumPaginas() {
        return numPaginas;
    }

    public void setNumPaginas(int numPaginas) {
        this.numPaginas = numPaginas;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    // Métodos
    public void aplicarDesconto() {
        if (this.preco > 15) {
            this.preco -= 15;
            System.out.println(this.titulo + " teve 15 reais de desconto.");
        } else {
            System.out.println(this.titulo + " não pode ter desconto porque o preço é menor ou igual a 15 reais.");
        }
    }

    public void exibirInfo() {
        System.out.println("Título: " + this.titulo);
        System.out.println("Autor: " + this.autor);
        System.out.println("Número de Páginas: " + this.numPaginas);
        System.out.println("Preço: " + this.preco);
    }

    public static void main(String[] args) {
        // Criando objetos da classe Exercicio02
        Exercicio02 jonhys = new Exercicio02("Livro A", "Autor A", 200, 30);
        Exercicio02 jonhys2 = new Exercicio02("Livro B", "Autor B", 150, 12);
        Exercicio02 jonhys3 = new Exercicio02("Livro C", "Autor C", 100, 20);
        
        // Exibindo informações e aplicando desconto
        jonhys.exibirInfo();
        jonhys.aplicarDesconto();
        jonhys.exibirInfo();
        
        jonhys2.exibirInfo();
        jonhys2.aplicarDesconto();
        jonhys2.exibirInfo();
        
        jonhys3.exibirInfo();
        jonhys3.aplicarDesconto();
        jonhys3.exibirInfo();
    }
}
