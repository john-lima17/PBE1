package ListaExercicios;

public class Exercicio03 {
	
	// Atributos
	String nome;
	int idade;
	String raca;
	
	// Construtor padrão
	public Exercicio03() {
		this.nome = "";
		this.raca = "";
		this.idade = 2;
	}
	
	// Construtor parametrizado
	public Exercicio03(String nome, String raca, int idade) {
	    this.nome = nome;
	    this.raca = raca;
	    this.idade = idade;
	}
	
	// Métodos
	public void emitirSom() {
		System.out.println("O animal fez um som.");
	
	}
}
