	package ListaExercicios;

	public class ContaPoupanca extends ContaBancaria {

	    // Atributo adicional
	    private double taxaJuros;

	    // Construtor padrão
	    public ContaPoupanca() {
	        super();
	        this.taxaJuros = 0.0;
	    }

	    // Construtor parametrizado
	    public ContaPoupanca(int numero, String titular, double saldo, double taxaJuros) {
	        super(numero, titular, saldo);
	        this.taxaJuros = taxaJuros;
	    }
	}

}
