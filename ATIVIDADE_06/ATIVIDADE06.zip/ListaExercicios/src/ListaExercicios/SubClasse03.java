package ListaExercicios;

// Definindo a classe SubClasse03
public class SubClasse03 {

    // Método nadar, agora definido corretamente dentro da classe
    public void nadar() {
        System.out.println("A baleia está nadando.");
    }
    public static void main(String[] args) {
     
    }
}
