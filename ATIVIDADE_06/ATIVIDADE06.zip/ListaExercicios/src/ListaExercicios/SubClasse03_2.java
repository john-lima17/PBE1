package ListaExercicios;

public class SubClasse03_2 {

    // Método cacar definido dentro da classe
    public void cacar() {
        System.out.println("O leão está caçando.");
    }

    public static void main(String[] args) {
        
        SubClasse03_2 leao = new SubClasse03_2();
        
        leao.cacar();
    }
}
